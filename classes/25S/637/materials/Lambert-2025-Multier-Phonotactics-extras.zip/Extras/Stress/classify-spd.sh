#!/bin/sh
st2=st2-v1-archive-0415
outdir=SPD
out=spd.csv
if ! [ -d "${st2}" ]; then
	>&2 printf '%s\n' 'no StressTyp2 archive found.'
	>&2 printf '\t%s\n' \
	'please obtain the archive and extract it here.' \
	'http://st2.ullet.net/files/files/st2-v1-archive-0415.tar.gz'
	exit 1
fi
if ! [ -d "${outdir}" ]; then
	mkdir "${outdir}"
fi
for file in "${st2}"/transducers/fsasAtt/*; do
	base=$(basename "${file}")
	classify -A SL MTDef MTRDef PT MTGD \
	<"${file}" \
	>"SPD/${base%.fsa.att}.txt" \
	|| :
done
cd "${outdir}"
printf 'id,name,SL,MTDef,MTRDef,PT,MTGD\n' >"${out}"
for file in *.txt; do
	id="${file%%_*}"
	base="${file%.txt}"
	name="${base#*_}"
	printf '%s,%s' "${id}" "${name}" >>"${out}"
	<"$file" tr -dc '(us' | tr '(us' ',10' >>"${out}"
	printf '\n' >>"${out}"
done
