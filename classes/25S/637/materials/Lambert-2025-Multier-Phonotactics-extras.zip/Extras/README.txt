# Algebraic analysis of multitier phonotactics

These materials are broken into three components:

* Harmony
* Stress
* Tone

In the Harmony and Tone section, one finds PLEB files that are intended
to be interpreted by plebby from the Language Toolkit, obtained from [1].
Run plebby, and you will find yourself in the PLEB interpreter.

To import the description of the language, you would run something like:

    > :reset
    > :import Harmony/symmetric.pleb

Then, each file has a list of suggested commands to run, or you can
explore the patterns on your own using any of the available tools.
For example,

    > :isPT symmetric
    True
    > :isLT symmetric
    True

The Stress section also contains PLEB files for the stress-final,
stress-penult and stress-initial constraints, as well as the basic
four-way unbounded stress typology.  There is also a POSIX-compatible
shell script that runs the classification on the patterns from
the StressTyp2 database.

In order to run this script, first obtain the version 1 archive
from [2], then extract that archive into the Stress directory.
You should have a path Stress/st2-v1-archive-0415/transducers
which contains the finite-state descriptions of the patterns.
Then run the classify-spd script to populate the "SPD" output directory.

    $ (cd Stress && sh classify-spd.sh)

This directory is prepopulated here.

[1]: https://hackage.haskell.org/package/language-toolkit
[2]: http://st2.ullet.net/files/files/st2-v1-archive-0415.tar.gz
